package com.example.searchresult;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.navigation.NavigationView;

import java.util.Collections;
import java.util.List;

public class BottomNavigationDrawerFragment  extends BottomSheetDialogFragment {
    View view;
    NavigationView navigationView;
    SingletonList singletonList = SingletonList.getInstance();

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_bottomsheet,container,false);

        navigationView = view.findViewById(R.id.naviagtion_view_ps);

        navigationView.setNavigationItemSelectedListener(menuItem ->
        {

            switch(menuItem.getItemId())
            {
                case R.id.sort_low_price_ps:

                    Toast.makeText(getContext(),"sortLow",Toast.LENGTH_SHORT).show();
                    sortPrice(singletonList.getSearchLists(),0);
                    singletonList.getRecyclerAdapterSearch().notifyDataSetChanged();
                    dismiss();
                    return true;
                case R.id.sort_high_price_ps:
                Toast.makeText(getContext(),"high",Toast.LENGTH_SHORT).show();
                sortPrice(singletonList.getSearchLists(),1);
                singletonList.getRecyclerAdapterSearch().notifyDataSetChanged();
                dismiss();
                return true;
                case R.id.sort_popularity_ps:
                Toast.makeText(getContext(),"pop",Toast.LENGTH_SHORT).show();
                sortPop(singletonList.getSearchLists());
                singletonList.getRecyclerAdapterSearch().notifyDataSetChanged();
                dismiss();
                return true;
            }

         return true;
        });



        return view;
    }
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void sortPrice(List<SearchList> searchLists, int index)
    {  if(index == 0)
        Collections.sort(searchLists, (o1, o2) -> Integer.valueOf((int) (o1.getLowPrice()-o2.getLowPrice())));
       else
    {
        Toast.makeText(getContext(),"entered",Toast.LENGTH_SHORT).show();
        Collections.sort(searchLists, (o1, o2) -> Integer.valueOf((int) (o1.getLowPrice()-o2.getLowPrice())));
        Collections.reverse(searchLists);

    }

    }

    public void sortPop(List<SearchList> searchLists)
    {
        Collections.sort(searchLists, (o1, o2) -> Integer.valueOf(o1.getNoOfSold())-Integer.valueOf(o2.getNoOfSold()));
    }

}

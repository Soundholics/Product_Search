package com.example.searchresult;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class FilterActivity extends AppCompatActivity implements RecyclerAdapterFilter.FilterData {



    private FilterStrings filterStrings;
    private FilterState filterState;
    RecyclerAdapterFilter recyclerAdapterFilter;
    private List<String> filterToServer = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        filterStrings = new FilterStrings();
         filterState = new FilterState();

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_filter);
        findViewById(R.id.price_filter_ps).performClick();

        findViewById(R.id.filter_apply_ps).setOnClickListener(view ->
        {
            String print ="";
            for (String s:filterToServer
                 ) {
                print += s+";";
            }
            Toast.makeText(getApplicationContext(),print,Toast.LENGTH_SHORT).show();
        });
    }




    @Override
    public void onUserClick(String filter) {

    }
    @Override
    public void preserveState(int position,int index,Boolean data,String filterVal)
    {

         filterState.indexString(index).set(position,data);
        Toast.makeText(getApplicationContext(),""+position+" "+index+" "+data.toString(),Toast.LENGTH_SHORT).show();
        if(filterToServer.contains(filterVal))
        {
            filterToServer.remove(filterVal);
        }else
        {
            filterToServer.add(filterVal);
        }
         recyclerAdapterFilter.notifyDataSetChanged();

    }
    private void renderFilter(int index)
    {
        List<String> stringList = new ArrayList<>();
        stringList = filterStrings.indexString(index);

        RecyclerView recyclerView = findViewById(R.id.recycler_view_filters_ps);
        recyclerAdapterFilter = new RecyclerAdapterFilter(FilterActivity.this,stringList,filterState.indexString(index),index);
       // filterStrings.indexString(index);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recyclerAdapterFilter);
    }

    public void onClick(View view)
    {
        switch(view.getId())
        {
            case R.id.price_filter_ps:
                renderFilter(0);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                break;
            case R.id.brand_filter_ps:
                renderFilter(1);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                break;
            case R.id.color_filter_ps:
                renderFilter(2);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                break;
            case R.id.connectivity_filter_ps:
                renderFilter(3);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                System.out.println("hello");
                break;
            case R.id.ergonomics_filter_ps:
                renderFilter(4);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                break;
            case R.id.catgory_filter_ps:
                renderFilter(5);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                break;
            case R.id.rating_filter_ps:
                renderFilter(6);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.white);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.grey);
                break;
            case R.id.stock_filter_ps:
                renderFilter(7);
                findViewById(R.id.price_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.brand_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.color_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.connectivity_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.ergonomics_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.catgory_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.rating_filter_ps).setBackgroundResource(R.color.grey);
                findViewById(R.id.stock_filter_ps).setBackgroundResource(R.color.white);
                break;


        }
    }
}
package com.example.searchresult;

import java.util.ArrayList;
import java.util.List;

public class FilterState {

    List<Boolean> price = new ArrayList<>();
    List<Boolean> brand = new ArrayList<>();
    List<Boolean> colors = new ArrayList<>();
    List<Boolean> connectivity = new ArrayList<>();
    List<Boolean> ergonomics = new ArrayList<>();
    List<Boolean> category = new ArrayList<>();
    List<Boolean> rating = new ArrayList<>();
    List<Boolean>  stock = new ArrayList<>();

    public FilterState() {
        price.add(false);
        price.add(false);
        price.add(false);
        price.add(false);
        price.add(false);
        price.add(false);
        price.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        brand.add(false);
        colors.add(false);
        colors.add(false);
        colors.add(false);
        colors.add(false);
        colors.add(false);
        colors.add(false);
        colors.add(false);
        colors.add(false);
        connectivity.add(false);
        connectivity.add(false);
        ergonomics.add(false);
        category.add(false);
        rating.add(false);
        stock.add(false);

    }



    public List<Boolean> indexString(int index)
    {
        switch (index){
            case 0:
                return price;
            case 1:
                return brand;
            case 2:
                return colors;
            case 3:
                return connectivity;
            case 4:
                return ergonomics;
            case 5:
                return category;
            case 6:
                return rating;
            case 7:
                return stock;

        }
        return price;//changes this
    }
}

package com.example.searchresult;

import android.widget.Switch;

import java.util.ArrayList;
import java.util.List;

public class FilterStrings {



     List<String> price = new ArrayList<>();
     List<String> brand = new ArrayList<>();
     List<String> colors = new ArrayList<>();
     List<String> connectivity = new ArrayList<>();
     List<String> ergonomics = new ArrayList<>();
     List<String> category = new ArrayList<>();
     List<String> rating = new ArrayList<>();
     List<String>  stock = new ArrayList<>();

    public FilterStrings() {
        price.add("Rs. 498 and Below");
        price.add("Rs. 499 - 998");
        price.add("Rs. 999 - 1498");
        price.add("Rs. 1499 - 1998");
        price.add("Rs. 1999 - 2498");
        price.add("Rs. 2499 - 4998");
        price.add("Rs. 4999 and Above");
        brand.add("JBL");
        brand.add("SkullCandy");
        brand.add("Sony");
        brand.add("Bose");
        brand.add("Sennheiser");
        brand.add("Ubon");
        brand.add("Boat");
        brand.add("Samsung");
        brand.add("Apple");
        colors.add("Red");
        colors.add("Black");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Cyan");
        colors.add("Olive");
        colors.add("Purple");
        colors.add("Brown");
        connectivity.add("Wired");
        connectivity.add("WireLess");
        ergonomics.add("Over");
        category.add("headphones");
        rating.add("2 star and above");
        stock.add("excluude out of stock");

    }


    public List<String> getPrice() {
        return price;
    }

    public void setPrice(List<String> price) {
        this.price = price;
    }

    public List<String> getBrand() {
        return brand;
    }

    public void setBrand(List<String> brand) {
        this.brand = brand;
    }

    public List<String> getColors() {
        return colors;
    }

    public void setColors(List<String> color) {
        colors = color;
    }

    public List<String> getConnectivity() {
        return connectivity;
    }

    public void setConnectivity(List<String> connectivity) {
        this.connectivity = connectivity;
    }

    public List<String> getErgonomics() {
        return ergonomics;
    }

    public void setErgonomics(List<String> ergonomics) {
        this.ergonomics = ergonomics;
    }

    public List<String> getCategory() {
        return category;
    }

    public void setCategory(List<String> category) {
        this.category = category;
    }

    public List<String> getRating() {
        return rating;
    }

    public void setRating(List<String> rating) {
        this.rating = rating;
    }

    public List<String> getStock() {
        return stock;
    }

    public void setStock(List<String> stock) {
        this.stock = stock;
    }
    public List<String> indexString(int index)
    {
        switch (index){
            case 0:
                return price;
            case 1:
                return brand;
            case 2:
                return colors;
            case 3:
                return connectivity;
            case 4:
                return ergonomics;
            case 5:
                return category;
            case 6:
                return rating;
            case 7:
                return stock;

        }
       return price;//changes this
    }
}

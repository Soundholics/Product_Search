package com.example.searchresult;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ProductSearchActivity extends AppCompatActivity implements RecyclerAdapterSearch.UserDataInterface {

    List<SearchList> searchListsLocal = new ArrayList<>();
    SingletonList singletonList = SingletonList.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_product_search);
        BottomNavigationDrawerFragment bottomNavigationDrawerFragment = new BottomNavigationDrawerFragment();

        populateData(searchListsLocal);
        singletonList.setSearchLists(searchListsLocal);
        RecyclerView recyclerView = findViewById(R.id.recycler_view_items_ps);
        RecyclerAdapterSearch recyclerAdapterSearch = new RecyclerAdapterSearch(singletonList.getSearchLists(), ProductSearchActivity.this);
        singletonList.setRecyclerAdapterSearch(recyclerAdapterSearch);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(singletonList.getRecyclerAdapterSearch());


        findViewById(R.id.sort_ps).setOnClickListener(view->
        {
           // setContentView(R.layout.activity_main);

            bottomNavigationDrawerFragment.show(getSupportFragmentManager(),bottomNavigationDrawerFragment.getTag());


        });

        findViewById(R.id.filter_ps).setOnClickListener(view->
        {
            Intent intent = new Intent(this,FilterActivity.class);
            startActivity(intent);
        });


        SearchView searchView = findViewById(R.id.searchView_ps);
        searchView.setOnClickListener(v ->
        {
            searchView.setIconified(false);
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public boolean onQueryTextSubmit(String query) {
                Toast.makeText(ProductSearchActivity.this,query,Toast.LENGTH_SHORT).show();
                closeKeyboard();
                //Intent Back to product search page that is this page
                Intent intent = new Intent(getApplicationContext(),ProductSearchActivity.class);
                startActivity(intent);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });




    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }








    private void populateData(List<SearchList> searchLists) {
        List<Attributes> attributesList = new ArrayList<>();
        String arr[] = new String[1];
        arr[0] = "https://fortmyersradon.com/wp-content/uploads/2019/12/dummy-user-img-1.png";
        attributesList.add(new Attributes("color","red"));
        searchLists.add(new SearchList("hbfjkgbdf","jksdfkjhsdjkfhkjsbfkjbskjf","inear",23,"23",4.8,200,arr,attributesList));
        searchLists.add(new SearchList("hbfjkgbdf","earphones","inear",23,"23",4.2,3000,arr,attributesList));
        searchLists.add(new SearchList("hbfjkgbdf","gurmpones","inear",23,"24",4.3,1500,arr,attributesList));
        searchLists.add(new SearchList("hbfjkgbdf","dulmones","inear",23,"25",4.4,1000,arr,attributesList));
        searchLists.add(new SearchList("hbfjkgbdf","oudomones","inear",23,"26",4.6,2000,arr,attributesList));
        searchLists.add(new SearchList("hbfjkgbdf","kariyama","inear",23,"27",3.9,2900,arr,attributesList));
        searchLists.add(new SearchList("hbfjkgbdf","bariyama","inear",23,"28",4.6,6000,arr,attributesList));

    }

    @Override
    public void onUserClick(SearchList userData) {
        Toast.makeText(this, "Image Clicked for" + userData.getId(), Toast.LENGTH_SHORT).show();
    }


    public void sortPop(MenuItem item) {
        Toast.makeText(getApplicationContext(),"hello sort",Toast.LENGTH_SHORT).show();
    }


}
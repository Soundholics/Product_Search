package com.example.searchresult;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapterFilter extends  RecyclerView.Adapter<RecyclerAdapterFilter.ViewHolder> {

    private final FilterActivity filterActivity;
    private final List<String> stringList;
    private final List<Boolean> filterStates;
    private final int index;


    public RecyclerAdapterFilter(FilterActivity filterActivity, List<String> stringList, List<Boolean> filterStates,int index) {
        this.filterActivity = filterActivity;
        this.stringList = stringList;
        this.filterStates = filterStates;
        this.index = index;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.filter_items, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        String filter = stringList.get(position);
        Boolean bool = filterStates.get(position);
        holder.cbFilter.setText(filter);
        holder.cbFilter.setChecked(bool);
        holder.rootView.findViewById(R.id.checkBox_ps).setOnClickListener(view ->
        {
            Boolean biro = holder.cbFilter.isChecked();
            filterActivity.preserveState(position,index,biro,filter);
          //  Toast.makeText(filterActivity, "saved" + biro.toString(), Toast.LENGTH_SHORT).show();;
        });



    }
    public interface FilterData {
        void onUserClick(String filter);
        void preserveState(int position,int index,Boolean data,String filter);
    }

    @Override
    public int getItemCount() {
        return stringList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        private final CheckBox cbFilter;
        private final View rootView;


        public ViewHolder(@NonNull View view) {
            super(view);
            this.rootView = view;
            this.cbFilter = view.findViewById(R.id.checkBox_ps);
        }
    }
}

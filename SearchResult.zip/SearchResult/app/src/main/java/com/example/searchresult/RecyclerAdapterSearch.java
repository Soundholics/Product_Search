package com.example.searchresult;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class RecyclerAdapterSearch extends RecyclerView.Adapter<RecyclerAdapterSearch.ViewHolder> {

    private final List<SearchList> searchLists;
    private final ProductSearchActivity productSearchActivity;

    public RecyclerAdapterSearch(List<SearchList> searchLists, ProductSearchActivity productSearchActivity) {
        this.searchLists = searchLists;

        this.productSearchActivity = productSearchActivity;
    }

    @NonNull
    @Override
    public RecyclerAdapterSearch.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.search_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapterSearch.ViewHolder holder, int position) {
        SearchList userData = searchLists.get(position);
        holder.tvName.setText(userData.getName());
        holder.tvRating.setText(String.valueOf(userData.getRatingAv())+"⭐️");
        holder.tvPrice.setText("$"+String.valueOf(userData.getLowPrice()));
        Glide.with(holder.ivSeachitem.getContext()).load(userData.getImgUrl()[0]).placeholder(R.drawable.placeholder).into(holder.ivSeachitem);

        holder.rootView.setOnClickListener((view -> productSearchActivity.onUserClick(userData)));

    }

    @Override
    public int getItemCount() {
        return searchLists.size() ;
    }
    public interface UserDataInterface {
        void onUserClick(SearchList userData);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        private final TextView tvName;
        private final TextView tvPrice;
        private final View rootView;
        private  final TextView tvRating;
        private final ImageView ivSeachitem;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.rootView = view;
            this.tvName = view.findViewById(R.id.search_item_name_ps);
            this.tvPrice = view.findViewById(R.id.search_item_price_ps);
            this.tvRating = view.findViewById(R.id.search_item_rating_ps);
            this.ivSeachitem = view.findViewById(R.id.search_image_item_ps);
        }
    }
}

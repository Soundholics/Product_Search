package com.example.searchresult;

import java.io.Serializable;
import java.util.List;

public class SearchList  {

   // private static SearchList instance;
    private String id;
    private String name;
    private String category;
    private int stock;
    private String noOfSold;
    private double ratingAv;
    private double lowPrice;
    private String imgUrl[];
    private List<Attributes> attributesList;

//    private SearchList() { }
//    public static SearchList getInstance()
//    {
//        if(instance == null)
//        {
//            synchronized (SearchList.class){
//                if(instance == null)
//                {
//                    instance = new SearchList();
//
//                }
//            }
//        }
//        return instance;
//    }

    public SearchList(String id, String name, String category, int stock, String noOfSold, double ratingAv, double lowPrice, String[] imgUrl, List<Attributes> attributesList) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.stock = stock;
        this.noOfSold = noOfSold;
        this.ratingAv = ratingAv;
        this.lowPrice = lowPrice;
        this.imgUrl = imgUrl;
        this.attributesList = attributesList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getNoOfSold() {
        return noOfSold;
    }

    public void setNoOfSold(String noOfSold) {
        this.noOfSold = noOfSold;
    }

    public List<Attributes> getAttributesList() {
        return attributesList;
    }

    public void setAttributesList(List<Attributes> attributesList) {
        this.attributesList = attributesList;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getRatingAv() {
        return ratingAv;
    }

    public void setRatingAv(double ratingAv) {
        this.ratingAv = ratingAv;
    }

    public double getLowPrice() {
        return lowPrice;
    }

    public void setLowPrice(double lowPrice) {
        this.lowPrice = lowPrice;
    }

    public String[] getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String[] imgUrl) {
        this.imgUrl = imgUrl;
    }
}

package com.example.searchresult;

import java.util.List;

public class SingletonList {

    private static SingletonList instance;
    private List<SearchList>  searchLists;
    private RecyclerAdapterSearch recyclerAdapterSearch;

    private SingletonList() {
    }

    public static SingletonList getInstance()
    {
        if(instance == null)
        {
            synchronized (SingletonList.class){
                if(instance == null)
                {
                    instance = new SingletonList();

                }
            }
        }
        return instance;
    }

    public List<SearchList> getSearchLists() {
        return searchLists;
    }

    public void setSearchLists(List<SearchList> searchLists) {
        this.searchLists = searchLists;
    }

    public RecyclerAdapterSearch getRecyclerAdapterSearch() {
        return recyclerAdapterSearch;
    }

    public void setRecyclerAdapterSearch(RecyclerAdapterSearch recyclerAdapterSearch) {
        this.recyclerAdapterSearch = recyclerAdapterSearch;
    }
}
